﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Admin : Form
    {
        bd_enemis db = new bd_enemis();

        public Admin()
        {
            InitializeComponent();
            dataGridView1.DataSource = db.Users.ToList();
            foreach (var rr in db.Offices)
            {
                comboBox1.Items.Add(rr.Title);
                dict.Add(rr.ID, rr.Title);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Admin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }


        public void Change_FormClosing()
        {
            dataGridView1.DataSource = db.Users.ToList();
        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUser au = new AddUser(db,this);
            au.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows != null)
            {
                EditRole er = new EditRole(db.Users.ToList()[dataGridView1.SelectedCells[0].RowIndex],db,this);
                er.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            db.Users.ToList()[dataGridView1.SelectedCells[0].RowIndex].Active = !db.Users.ToList()[dataGridView1.SelectedCells[0].RowIndex].Active;
            db.SaveChanges();
            dataGridView1.DataSource = db.Users.ToList();
        }
        Dictionary<int, string> dict = new Dictionary<int, string>();

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            int xxx = dict.First(t => t.Value == comboBox1.Items[comboBox1.SelectedIndex].ToString()).Key;
            var r = (from q in db.Users where q.OfficeID== xxx select q);
            dataGridView1.DataSource = r.ToList();

        }
    }
}
