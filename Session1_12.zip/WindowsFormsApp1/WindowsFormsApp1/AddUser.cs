﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AddUser : Form
    {
        Dictionary<int, string> dict = new Dictionary<int, string>();
        bd_enemis db;
        Admin add;
        public AddUser(bd_enemis bd, Admin ad)
        {
            InitializeComponent();
            db = bd;
            add = ad;
            foreach (var rr in db.Offices)
            {
                comboBox1.Items.Add(rr.Title);
                dict.Add(rr.ID, rr.Title);
            }
        }

        private void AddUser_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Users user = new Users();

            if (textBox1.Text == "") { MessageBox.Show("provide user's email"); return; }
            if (textBox3.Text == "") { MessageBox.Show("provide user's first name"); return; }
            if (textBox4.Text == "") { MessageBox.Show("provide user's password"); return; }

            if (dateTimePicker1.Value.Date!=DateTime.Now.Date)
            {
                user.Birthdate = dateTimePicker1.Value.Date;
            }

            user.Email = textBox1.Text;
            user.FirstName = textBox3.Text;
            user.LastName = textBox2.Text;
            user.Password = textBox4.Text;
            user.OfficeID = dict.First(t => t.Value == comboBox1.Text).Key;
            user.RoleID = 1;
            db.Users.Add(user);
            db.SaveChanges();
            add.dataGridView1.DataSource = db.Users.ToList();
            Close();
        }
    }
}
