﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class User : Form
    {
        Users curUser;
        bd_enemis db=new bd_enemis();
        public User(Users userId)
        {
            //var r=(from d in db. )
            InitializeComponent();
            timer1.Start();
            curUser = userId;
            label1.Text= "Hi"+userId.FirstName+" " + userId.LastName+", Welcome to AMONIC Airlines Automation System";
            logTim = DateTime.Now;
            dataGridView1.DataSource = (from df in db.UsersLoginHistory where df.UserID == userId.ID select df).ToList();

            var sad=(from df in db.UsersLoginHistory where df.UserID == userId.ID select df).ToList();
            TimeSpan ts=new TimeSpan();
            foreach(var rr in sad)
            {
                if (DateTime.Now.Subtract(rr.Date).TotalDays < 30)
                {
                    ts = ts.Add(rr.Time_spent_on_system.Value);
                }
            }
            mm = ts.Minutes;
            ss = ts.Seconds;
            hh = ts.Hours;
            label2.Text = "Time spent on system: " + (hh / 10).ToString() + (hh % 10).ToString() + ":" + (mm / 10).ToString() + (mm % 10).ToString() + ":" + (ss / 10).ToString() + (ss % 10).ToString();
        }
        DateTime logTim;

        private void User_Load(object sender, EventArgs e)
        {
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        bool l=true;
        private void User_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (l)
            {
                UsersLoginHistory ul = new UsersLoginHistory();
                ul.UserID = curUser.ID;
                ul.Date = DateTime.Now.Date;
                ul.Login_time = logTim.TimeOfDay;
                ul.Logout_time = DateTime.Now.TimeOfDay;
                ul.Time_spent_on_system = DateTime.Now.Subtract(logTim);
                db.UsersLoginHistory.Add(ul);
                db.SaveChanges();
                l = false;
            }
            Application.Exit();
        }

        int hh=0, mm=0, ss=0;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ss++;
            if (ss >= 60) { mm++; ss = 0; }
            if (mm >= 60) { hh++; mm = 0; }
            label2.Text= "Time spent on system: "+ (hh / 10).ToString() + (hh % 10).ToString() + ":"+ (mm / 10).ToString() + (mm % 10).ToString() + ":"+(ss/10).ToString()+(ss%10).ToString();
        }
    }
}
