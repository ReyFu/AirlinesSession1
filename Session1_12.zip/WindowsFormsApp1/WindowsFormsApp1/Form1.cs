﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        int timesWrong = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            bd_enemis db = new bd_enemis();
            var r = (from d in db.Users where d.Email == textBox1.Text && d.Password == textBox2.Text select d).ToList();
            if (r.Count() < 1) {
                MessageBox.Show("Oops you dont remember your passcode");
                timesWrong++;
                if (timesWrong >= 3)
                {
                    button1.Enabled = false;
                    timer1.Start();
                    MessageBox.Show("You entered wrong password 3 times. Now you will be forced to wait for 10 seconds!");
                }
            } else if(r[0].Active==false){
                MessageBox.Show("Your user not active");
            }
            else
            {
                if (r[0].RoleID == 1)
                {
                    Admin ad = new Admin();
                    ad.Show();
                    Hide();
                }
                else if (r[0].RoleID == 2)
                {
                    User ad = new User(r[0]);
                    ad.Show();
                    Hide();
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            button1.Enabled = true;
        }
    }
}
