﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class EditRole : Form
    {
        bd_enemis db;
        Users us;
        Dictionary<int, string> dict=new Dictionary<int, string>();

        public EditRole(Users sus, bd_enemis en, Admin add)
        {
            InitializeComponent();
            ad = add;
            db = en;
            us = sus;
            em.Text = sus.Email;
            nam.Text = sus.FirstName;
            fam.Text = sus.LastName;

            foreach(var r in db.Offices)
            {
                ofi.Items.Add(r.Title);
                dict.Add(r.ID,r.Title);
            }

            if (sus.OfficeID != null)
            {
                ofi.SelectedIndex = ofi.FindString(dict.First(t => t.Key == (int)sus.OfficeID).Value)  ;
            }

            radioButton1.Checked = sus.RoleID == 2;
            radioButton2.Checked = sus.RoleID == 1;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        Admin ad;

        private void button1_Click(object sender, EventArgs e)
        {
            us.LastName = fam.Text;
            us.FirstName = nam.Text;
            us.Email = em.Text;
            int tt = 0;

            if (radioButton1.Checked)
            {
                tt = 2;
            }
            else { tt = 1; }
            us.RoleID = tt;
            us.OfficeID = dict.First(t => t.Value == ofi.Text).Key;

            db.SaveChanges();
            ad.dataGridView1.DataSource = db.Users.ToList();
            Close();
        }
    }
}
